﻿namespace WeatherAppliction
{
    partial class WeatherDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WeatherDisplay));
            this.retrieveBtn = new System.Windows.Forms.Button();
            this.zipCodeInput = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.CurTemp = new System.Windows.Forms.Label();
            this.CityNameLabel = new System.Windows.Forms.Label();
            this.weatherDesc = new System.Windows.Forms.Label();
            this.todayHigh = new System.Windows.Forms.Label();
            this.todayLow = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // retrieveBtn
            // 
            this.retrieveBtn.BackColor = System.Drawing.SystemColors.Control;
            this.retrieveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retrieveBtn.Location = new System.Drawing.Point(269, 104);
            this.retrieveBtn.Name = "retrieveBtn";
            this.retrieveBtn.Size = new System.Drawing.Size(112, 38);
            this.retrieveBtn.TabIndex = 0;
            this.retrieveBtn.Text = "Submit";
            this.retrieveBtn.UseVisualStyleBackColor = false;
            this.retrieveBtn.Click += new System.EventHandler(this.retrieveBtn_Click);
            // 
            // zipCodeInput
            // 
            this.zipCodeInput.CausesValidation = false;
            this.zipCodeInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.zipCodeInput.Location = new System.Drawing.Point(12, 104);
            this.zipCodeInput.Name = "zipCodeInput";
            this.zipCodeInput.Size = new System.Drawing.Size(235, 38);
            this.zipCodeInput.TabIndex = 1;
            this.zipCodeInput.Enter += new System.EventHandler(this.RemoveText);
            this.zipCodeInput.Leave += new System.EventHandler(this.AddText);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(6, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(368, 42);
            this.label2.TabIndex = 8;
            this.label2.Text = "Today\'s Weather in:";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(209, 335);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(319, 42);
            this.label5.TabIndex = 11;
            this.label5.Text = "Today\'s Low:";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(209, 281);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(319, 42);
            this.label6.TabIndex = 12;
            this.label6.Text = "Today\'s High:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Location = new System.Drawing.Point(4, 214);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 185);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // CurTemp
            // 
            this.CurTemp.AutoSize = true;
            this.CurTemp.BackColor = System.Drawing.Color.Transparent;
            this.CurTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurTemp.ForeColor = System.Drawing.SystemColors.Window;
            this.CurTemp.Location = new System.Drawing.Point(534, 225);
            this.CurTemp.Name = "CurTemp";
            this.CurTemp.Size = new System.Drawing.Size(0, 42);
            this.CurTemp.TabIndex = 14;
            // 
            // CityNameLabel
            // 
            this.CityNameLabel.AutoSize = true;
            this.CityNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.CityNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityNameLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.CityNameLabel.Location = new System.Drawing.Point(381, 171);
            this.CityNameLabel.Name = "CityNameLabel";
            this.CityNameLabel.Size = new System.Drawing.Size(0, 42);
            this.CityNameLabel.TabIndex = 15;
            // 
            // weatherDesc
            // 
            this.weatherDesc.AutoSize = true;
            this.weatherDesc.BackColor = System.Drawing.Color.Transparent;
            this.weatherDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weatherDesc.ForeColor = System.Drawing.SystemColors.Window;
            this.weatherDesc.Location = new System.Drawing.Point(209, 227);
            this.weatherDesc.Name = "weatherDesc";
            this.weatherDesc.Size = new System.Drawing.Size(0, 42);
            this.weatherDesc.TabIndex = 16;
            // 
            // todayHigh
            // 
            this.todayHigh.AutoSize = true;
            this.todayHigh.BackColor = System.Drawing.Color.Transparent;
            this.todayHigh.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todayHigh.ForeColor = System.Drawing.SystemColors.Window;
            this.todayHigh.Location = new System.Drawing.Point(534, 281);
            this.todayHigh.Name = "todayHigh";
            this.todayHigh.Size = new System.Drawing.Size(0, 42);
            this.todayHigh.TabIndex = 17;
            // 
            // todayLow
            // 
            this.todayLow.AutoSize = true;
            this.todayLow.BackColor = System.Drawing.Color.Transparent;
            this.todayLow.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todayLow.ForeColor = System.Drawing.SystemColors.Window;
            this.todayLow.Location = new System.Drawing.Point(534, 335);
            this.todayLow.Name = "todayLow";
            this.todayLow.Size = new System.Drawing.Size(0, 42);
            this.todayLow.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(112, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(656, 73);
            this.label1.TabIndex = 19;
            this.label1.Text = "Weather by Zip Code";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(13, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // WeatherDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.todayLow);
            this.Controls.Add(this.todayHigh);
            this.Controls.Add(this.weatherDesc);
            this.Controls.Add(this.CityNameLabel);
            this.Controls.Add(this.CurTemp);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.zipCodeInput);
            this.Controls.Add(this.retrieveBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "WeatherDisplay";
            this.Text = "WeatherDisplay";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button retrieveBtn;
        private System.Windows.Forms.TextBox zipCodeInput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label CurTemp;
        private System.Windows.Forms.Label CityNameLabel;
        private System.Windows.Forms.Label weatherDesc;
        private System.Windows.Forms.Label todayHigh;
        private System.Windows.Forms.Label todayLow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}