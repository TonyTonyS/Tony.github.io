﻿using System;
using System.Windows.Forms;
using WeatherDisplay.DataClasses;
using WeatherDisplay.Helpers;
using System.Drawing;// Added for using images resources?
using System.Net;

namespace WeatherAppliction
{
    public partial class WeatherDisplay : Form
    {
        private string defaultSearchText = "Enter Zip Code...";

        public WeatherDisplay()
        {
            InitializeComponent();
            zipCodeInput.Text = defaultSearchText;
        }

        private void retrieveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (zipCodeInput.Text.Length < 5)
                {
                    MessageBox.Show("Please enter a valid zip code!", "Retrieve Weather Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                String zipCode = zipCodeInput.Text;

                SearchResult searchResult = WeatherDataService.retrieveSearchResult(zipCode);

                if (searchResult == null)
                {
                    MessageBox.Show("No Data Found! Please try again", "Retrieve Weather Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    CurTemp.Text = searchResult.CurrentTemp + "°";
                    CityNameLabel.Text = searchResult.LocalName;
                    weatherDesc.Text = searchResult.WeatherDesc + " at:";
                    todayHigh.Text = searchResult.MaxTemp + "°";
                    todayLow.Text = searchResult.MinTemp + "°";

                    // Weather icon controller
                    if (searchResult.WeatherIcon != null)
                    {
                        pictureBox1.Image = searchResult.WeatherIcon;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Retrieve Weather Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return;
        }

        public void RemoveText(object sender, EventArgs e)
        {
            if (zipCodeInput.Text == defaultSearchText)
                zipCodeInput.Text = String.Empty;
        }

        public void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(zipCodeInput.Text))
                zipCodeInput.Text = defaultSearchText;
        }
    }
}
