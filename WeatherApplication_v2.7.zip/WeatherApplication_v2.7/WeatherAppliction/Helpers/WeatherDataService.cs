﻿using Newtonsoft.Json.Linq;
using System;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using WeatherDisplay.DataClasses;

namespace WeatherDisplay.Helpers
{
    public class WeatherDataService
    {
        public static string SEARCH_URL = "http://api.openweathermap.org/data/2.5/weather?zip={0}&units={1}&APPID={2}";
        public static string units = "imperial";
        public static string API_KEY = "c8909ded9b0d68c30e6bed8f43d90793";

        /// <summary>
        /// called to hit weather data API and retrieve result for supplied zip code
        /// </summary>
        /// <param name="zipcode"> Required parameter to retrieve weather results.</param>
        public static SearchResult retrieveSearchResult(string zipcode)
        {
            SearchResult searchResult = null;

            //Move URL to another location and use string interpolation to enter zip code
            //NOTE: Always provide the API key
            string api_path = String.Format(SEARCH_URL, zipcode, units, API_KEY);

            //Necessary to make the call to the internet to get the data.  
            HttpClient client = new HttpClient();
            //Calls the endpoint
            var serviceresponse = client.GetAsync(api_path).Result;
            //Checks for a success status code (200)
            if (serviceresponse.IsSuccessStatusCode)
            {
                //Get the content from the response
                var responseContent = serviceresponse.Content;

                //Get the content into a string – async – you are still potentially pulling data down
                //JObject is a JSON LINQ object that can be queried
                JObject weatherSearch = JObject.Parse(responseContent.ReadAsStringAsync().Result);

                // serialize JSON results into .NET object
                // Search JObject using LINQ to assign values to new Search result object

                searchResult = new SearchResult
                {
                    LocalName = weatherSearch.SelectToken("name").ToString(),
                    WeatherDesc = weatherSearch.SelectToken("weather").Select(w => (string)w.SelectToken("description")).FirstOrDefault(),
                    WeatherIconCode = weatherSearch.SelectToken("weather").Select(w => (string)w.SelectToken("icon")).FirstOrDefault(),
                    CurrentTemp = weatherSearch.SelectToken("main.temp").ToString(),
                    MinTemp = weatherSearch.SelectToken("main.temp_min").ToString(),
                    MaxTemp = weatherSearch.SelectToken("main.temp_max").ToString(),
                };
            }

            if(searchResult.WeatherIconCode != null)
            {
                GetWeatherIcon(searchResult);
            }

            return searchResult;
        }

        public static void GetWeatherIcon(SearchResult searchResult)
        {
            // Weather icon controller
            if (searchResult.WeatherIconCode != null)
            {
                var request = WebRequest.Create("http://openweathermap.org/img/w/" + searchResult.WeatherIconCode + ".png");

                using (var response = request.GetResponse())
                using (var stream = response.GetResponseStream())
                {
                    searchResult.WeatherIcon = Bitmap.FromStream(stream);
                }
            }
        }
    }
}
