﻿using System.Drawing;

namespace WeatherDisplay.DataClasses
{
    public class SearchResult
    {
        public string LocalName { get; set; }
        public string WeatherDesc { get; set; }
        public string WeatherIconCode { get; set; }
        public Image WeatherIcon { get; set; }
        public string CurrentTemp { get; set; }
        public string MinTemp { get; set; }
        public string MaxTemp { get; set; }
    }
}
